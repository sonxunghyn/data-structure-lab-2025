def problem2(s: str) -> int:
    """
    주어진 괄호 문자열 s를 올바른 괄호열로 만들기 위해
    앞과 뒤에 추가해야 할 최소 괄호 개수를 반환합니다.
    """
    balance = 0   # 현재까지 열린 '(' 중 매칭되지 않은 개수
    additions = 0 # 앞과 뒤에 추가해야 할 괄호 총 개수

    for char in s:
        if char == '(':
            balance += 1
        elif char == ')':
            if balance > 0:
                balance -= 1
            else:
                # 매칭할 '('가 없으므로 앞에 '('를 하나 추가해야 함
                additions += 1

    # 남아 있는 열린 괄호 balance만큼 뒤에 ')'를 추가해야 함
    additions += balance
    return additions


if __name__ == "__main__":
    # 입력
    s = input().strip()

    # 처리 및 출력
    print(problem2(s))