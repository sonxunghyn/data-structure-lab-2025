def problem1(nums):
    """
    다섯 개의 자연수를 입력받아
    평균(mean)과 중앙값(median)을 계산하여 [mean, median] 형태로 반환.
    """

    mean = sum(nums) // len(nums)  # 평균 계산 (정수 나눗셈: 소수점 이하는 버림)
    
    sorted_nums = sorted(nums)  # 중앙값 계산
    median = sorted_nums[len(sorted_nums) // 2]
    
    return [mean, median]


if __name__ == "__main__":
    input_list = [10, 40, 30, 60, 30]  # 예제 입력 (프로젝트 문제 1번)
    
    result = problem1(input_list) # 함수 호출 및 결과 확인
    
    assert result == [34, 30], f"테스트 실패: {result}"  # 예상 결과 [34, 30]과 일치하는지 검사
    print("정답입니다.")