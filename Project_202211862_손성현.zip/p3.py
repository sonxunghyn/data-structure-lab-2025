from collections import deque

def problem3(forest, N=4):
    grid = [row[:] for row in forest]           # 격자 복사
    size, eaten, time = 2, 0, 0                  # 초기 크기, 먹은 횟수, 경과 시간
    for i in range(N):                          
        for j in range(N):
            if grid[i][j] == 9:
                sx, sy = i, j; grid[i][j] = 0    # 시작 위치 설정 및 0으로 초기화
                break
    dirs = [(-1,0),(0,-1),(0,1),(1,0)]           # 상, 좌, 우, 하 이동 벡터

    while True:
        dist = [[-1]*N for _ in range(N)]       # 거리 맵 초기화
        q = deque([(sx, sy)]); dist[sx][sy] = 0 # BFS 시작점 설정
        candidates, md = [], None               # 먹을 수 있는 후보와 최소 거리

        while q:
            x, y = q.popleft(); d = dist[x][y]  # 현재 위치와 거리
            if md is not None and d > md:       # 이미 더 가까운 후보가 있으면 스킵
                continue
            for dx, dy in dirs:
                nx, ny = x+dx, y+dy
                if 0<=nx<N and 0<=ny<N and dist[nx][ny]==-1 and grid[nx][ny]<=size:
                    dist[nx][ny] = d+1            # 거리 갱신
                    if 0 < grid[nx][ny] < size:
                        md = d+1                  # 최소 거리 업데이트
                        candidates.append((nx, ny, d+1))
                    q.append((nx, ny))           # 다음 탐색

        if not candidates:                       # 먹을 후보 없으면 종료
            break
        tx, ty, td = min(candidates, key=lambda x:(x[2], x[0], x[1]))  # 우선순위 선택
        time += td; sx, sy = tx, ty             # 이동 및 시간 누적
        grid[sx][sy] = 0; eaten += 1            # 벌집 먹기
        if eaten == size: size += 1; eaten = 0  # 크기 증가

    return time

if __name__ == "__main__":
    example = [
        [4, 3, 2, 1],
        [0, 0, 0, 0],
        [0, 0, 9, 0],
        [1, 2, 3, 4]
    ]
    print(problem3(example))  # 14
    print("정답입니다.")